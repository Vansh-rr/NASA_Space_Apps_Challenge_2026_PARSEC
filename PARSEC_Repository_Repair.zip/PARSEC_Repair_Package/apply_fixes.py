#!/usr/bin/env python3
"""Safely overlay the verified repair into a clean Git clone. Dry run unless --apply."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

PACKAGE = Path(__file__).resolve().parent
SOURCE = PACKAGE/'PARSEC'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def plan(target, manifest):
    writes, deletes, conflicts = [], [], []
    for name, item in manifest['files'].items():
        rel=Path(name)
        if rel.is_absolute() or '..' in rel.parts:
            raise ValueError('Unsafe path in manifest')
        dest=target/rel
        if not dest.resolve().is_relative_to(target):
            raise ValueError('Path escapes target clone: '+name)
        if dest.is_symlink() or any(p.is_symlink() for p in dest.parents if p != target.parent):
            conflicts.append(name+' (symbolic link)'); continue
        expected=item['corrected_sha256']
        if expected is not None and sha(SOURCE/rel) != expected:
            raise ValueError('Package integrity mismatch: '+name)
        if dest.exists() and not dest.is_file():
            conflicts.append(name+' (not a regular file)');continue
        actual=sha(dest) if dest.exists() else None
        if actual == expected:continue
        if actual is not None and actual not in item['known_original_sha256']:
            conflicts.append(name+' (differs from every uploaded version)');continue
        if expected is None:
            if dest.exists(): deletes.append(name)
        else:writes.append(name)
    return writes,deletes,conflicts


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('clone',type=Path,help='Root of an existing local Git clone')
    parser.add_argument('--apply',action='store_true',help='Apply after checking all paths and originals')
    args=parser.parse_args(argv)
    target=args.clone.resolve()
    try:
        root=subprocess.run(['git','rev-parse','--show-toplevel'],cwd=target,capture_output=True,text=True,check=True)
        if Path(root.stdout.strip()).resolve()!=target:raise ValueError('Select the root of the Git clone')
        manifest=json.loads((PACKAGE/'source_manifest.json').read_text())
        writes,deletes,conflicts=plan(target,manifest)
        if conflicts:
            print('Stopped before changing files. Resolve these conflicts manually:\n'+'\n'.join(conflicts),file=sys.stderr)
            return 2
        if not writes and not deletes:
            print('The clone already contains this repair. Nothing to change.');return 0
        status=subprocess.run(['git','status','--porcelain'],cwd=target,capture_output=True,text=True,check=True)
        if status.stdout.strip():raise ValueError('Use a clean worktree: commit or stash your own changes first')
        print(f'Plan: write {len(writes)} files; remove {len(deletes)} obsolete archive/history files.')
        for name in writes:print('  write  '+name)
        for name in deletes:print('  remove '+name)
        if not args.apply:
            print('Dry run only. Repeat with --apply to copy these files.');return 0
        # Back up only touched files and restore them if any copy fails.
        with tempfile.TemporaryDirectory(prefix='parsec_apply_backup_') as temp:
            backup=Path(temp)
            existing={name for name in writes+deletes if (target/name).is_file()}
            for name in existing:
                out=backup/name;out.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(target/name,out)
            try:
                for name in writes:
                    out=target/name;out.parent.mkdir(parents=True,exist_ok=True)
                    shutil.copy2(SOURCE/name,out)
                for name in deletes:(target/name).unlink()
            except OSError:
                for name in writes+deletes:
                    out=target/name
                    if name in existing:shutil.copy2(backup/name,out)
                    elif out.is_file():out.unlink()
                raise
        print('Applied. Run python run_tests.py --install, review git diff, then commit and push your branch.')
        return 0
    except (OSError,ValueError,KeyError,subprocess.CalledProcessError) as exc:
        print('ERROR: '+str(exc),file=sys.stderr);return 2


if __name__=='__main__':raise SystemExit(main())
